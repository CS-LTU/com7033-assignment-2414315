INSERT INTO users (username, password_hash)
VALUES (?, ?);
