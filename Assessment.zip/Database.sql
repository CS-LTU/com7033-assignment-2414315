-- Enable foreign key constraints
PRAGMA foreign_keys = ON;

--------------------------------------------------------
-- USERS TABLE (For Authentication)
--------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    user_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,         -- store hashed password only
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

--------------------------------------------------------
-- PATIENTS TABLE (Stroke Prediction Dataset)
--------------------------------------------------------
CREATE TABLE IF NOT EXISTS patients (
    id                  INTEGER PRIMARY KEY,   -- dataset id is unique
    gender              TEXT CHECK(gender IN ('Male','Female','Other')),
    age                 REAL CHECK(age >= 0),
    hypertension        INTEGER CHECK(hypertension IN (0,1)),
    ever_married        TEXT CHECK(ever_married IN ('Yes','No')),
    work_type           TEXT CHECK(work_type IN 
                          ('children','Govt_job','Never_worked','Private','Self-employed')),
    residence_type      TEXT CHECK(residence_type IN ('Rural','Urban')),
    avg_glucose_level   REAL CHECK(avg_glucose_level >= 0),
    bmi                 REAL,
    smoking_status      TEXT CHECK(smoking_status IN
                          ('formerly smoked','never smoked','smokes','unknown')),
    stroke              INTEGER CHECK(stroke IN (0,1))
);

--------------------------------------------------------
-- LOG TABLE (Optional - for secure audit logging)
--------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
    log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER,
    action      TEXT,
    timestamp   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);
