INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
