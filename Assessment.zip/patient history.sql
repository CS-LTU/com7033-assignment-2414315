-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
-- PART 5: Additional Indexing & Sample Insert

-- Indexes for faster queries
CREATE INDEX idx_gender ON patients (gender);
CREATE INDEX idx_work_type ON patients (work_type);
CREATE INDEX idx_stroke ON patients (stroke);

-- Input sanitisation example: enforce positive age & glucose
ALTER TABLE patients
    ADD CONSTRAINT chk_age CHECK (age >= 0),
    ADD CONSTRAINT chk_glucose CHECK (avg_glucose_level >= 0);

-- Sample user insert (password hash is just placeholder)
INSERT INTO users (username, email, password_hash, role)
VALUES ('admin1', 'admin@example.com', 'hashed_password_here', 'admin');

-- Sample patient record
INSERT INTO patients (
    id, gender, age, hypertension, ever_married, work_type,
    residence_type, avg_glucose_level, bmi, smoking_status, stroke
)
VALUES (
    1001, 'Male', 67, 1, 'Yes', 'Private',
    'Urban', 228.69, 36.6, 'smokes', 1
);
