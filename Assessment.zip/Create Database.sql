-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
-- PART 1: Create Database
CREATE DATABASE IF NOT EXISTS stroke_prediction_db;

-- Select database
USE stroke_prediction_db;
