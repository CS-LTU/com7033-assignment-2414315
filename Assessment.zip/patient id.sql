-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
-- PART 3: Patient Records Table
CREATE TABLE IF NOT EXISTS patients (
    id INT PRIMARY KEY,
    gender ENUM('Male', 'Female', 'Other'),
    age FLOAT NOT NULL,
    hypertension TINYINT(1) NOT NULL,
    ever_married ENUM('Yes', 'No'),
    work_type ENUM('Children', 'Govt_job', 'Never_worked', 'Private', 'Self-employed'),
    residence_type ENUM('Rural', 'Urban'),
    avg_glucose_level FLOAT NOT NULL,
    bmi FLOAT,
    smoking_status ENUM('formerly smoked', 'never smoked', 'smokes', 'unknown'),
    stroke TINYINT(1) NOT NULL
);
